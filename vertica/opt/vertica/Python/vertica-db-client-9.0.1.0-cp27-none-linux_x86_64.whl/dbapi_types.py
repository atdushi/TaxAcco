from time import localtime
from datetime import date, datetime, time

def Date(year, month, day):
    """Constructs a date value."""
    return date(year, month, day)

def Time(hour, minute=0, second=0, microsecond=0):
    """Constructs time value."""
    return time(hour, minute, second, microsecond)

def Timestamp(year, month, day, hour=0, minute=0, second=0, microsecond=0):
    """Constructs a timestamp value."""
    return datetime(year, month, day, hour, minute, second, microsecond)

def DateFromTicks(ticks):
    """Constructs a date value from a number of ticks."""
    return Date(*localtime(ticks)[:3])

def TimeFromTicks(ticks):
    """Constructs a time value from a number of ticks."""
    return Time(*localtime(ticks)[3:6])

def TimestampFromTicks(ticks):
    """Constructs a timestamp from a number of ticks."""
    return Timestamp(*localtime(ticks)[:6])

class Binary(str):
    """Constructs a binary (long) string."""
